package com.mushaf.hafs

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mushaf.hafs.data.Prefs
import com.mushaf.hafs.data.Quran
import com.mushaf.hafs.data.QuranRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.net.UnknownHostException

sealed interface LoadState {
    data object NeedsDownload : LoadState
    data class Downloading(val progress: Float, val label: String) : LoadState
    data object Loading : LoadState
    data class Ready(val quran: Quran) : LoadState
    data class Error(val message: String) : LoadState
}

class AppViewModel(app: Application) : AndroidViewModel(app) {
    val prefs = Prefs(app)
    private val repo = QuranRepository(app)

    private val _state = MutableStateFlow<LoadState>(
        if (repo.isDownloaded()) LoadState.Loading else LoadState.NeedsDownload,
    )
    val state: StateFlow<LoadState> = _state.asStateFlow()

    init {
        if (repo.isDownloaded()) viewModelScope.launch { loadFromDisk() }
    }

    fun download() {
        viewModelScope.launch {
            _state.value = LoadState.Downloading(0f, "جاري الاتصال…")
            try {
                repo.download { progress, label -> _state.value = LoadState.Downloading(progress, label) }
            } catch (e: UnknownHostException) {
                _state.value = LoadState.Error("تعذر الاتصال بالإنترنت. تحقق من اتصالك ثم أعد المحاولة.")
                return@launch
            } catch (e: Exception) {
                _state.value = LoadState.Error(e.message ?: "تعذر تنزيل البيانات. أعد المحاولة.")
                return@launch
            }
            loadFromDisk()
        }
    }

    fun retry() = download()

    /** حذف البيانات المحلية وإعادة تنزيلها. */
    fun redownload() {
        repo.clear()
        download()
    }

    private suspend fun loadFromDisk() {
        _state.value = LoadState.Loading
        try {
            _state.value = LoadState.Ready(repo.load())
        } catch (e: Exception) {
            repo.clear()
            _state.value = LoadState.Error("البيانات المخزنة تالفة وسيُعاد تنزيلها. اضغط «إعادة المحاولة».")
        }
    }
}
