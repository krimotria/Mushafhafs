package com.mushaf.hafs.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * يجلب النصوص مرة واحدة من واجهة Al Quran Cloud ويخزنها في ذاكرة التطبيق،
 * ثم يقرأ منها دون إنترنت.
 *
 *  - quran-uthmani : النص العثماني برواية حفص عن عاصم
 *  - quran-tajweed : النص نفسه بترميز أحكام التجويد
 *  - ar.muyassar   : التفسير الميسر
 */
class QuranRepository(context: Context) {

    data class Edition(val id: String, val label: String)

    companion object {
        private const val BASE_URL = "https://api.alquran.cloud/v1/quran/"
        private const val MIN_VALID_BYTES = 100_000L
        const val TOTAL_SURAHS = 114
        const val TOTAL_AYAHS = 6236

        val EDITIONS = listOf(
            Edition("quran-uthmani", "نص المصحف برواية حفص"),
            Edition("quran-tajweed", "ترميز أحكام التجويد"),
            Edition("ar.muyassar", "التفسير الميسر"),
        )
    }

    private val dir = File(context.filesDir, "quran_data")

    private fun fileOf(e: Edition) = File(dir, "${e.id}.json")

    fun isDownloaded(): Boolean = EDITIONS.all { fileOf(it).length() > MIN_VALID_BYTES }

    fun clear() {
        dir.deleteRecursively()
    }

    suspend fun download(onProgress: (Float, String) -> Unit) = withContext(Dispatchers.IO) {
        dir.mkdirs()
        EDITIONS.forEachIndexed { index, edition ->
            val target = fileOf(edition)
            if (target.length() > MIN_VALID_BYTES) {
                onProgress((index + 1f) / EDITIONS.size, edition.label)
                return@forEachIndexed
            }
            onProgress(index.toFloat() / EDITIONS.size, edition.label)
            val tmp = File(dir, "${edition.id}.part")
            downloadTo(BASE_URL + edition.id, tmp) { fraction ->
                onProgress((index + fraction) / EDITIONS.size, edition.label)
            }
            validate(tmp, edition)
            if (target.exists()) target.delete()
            if (!tmp.renameTo(target)) throw IOException("تعذر حفظ الملف على الجهاز")
        }
        onProgress(1f, "اكتمل التنزيل")
    }

    private fun downloadTo(url: String, out: File, onFraction: (Float) -> Unit) {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 20_000
            readTimeout = 60_000
            requestMethod = "GET"
            setRequestProperty("Accept", "application/json")
        }
        try {
            if (conn.responseCode != HttpURLConnection.HTTP_OK) {
                throw IOException("استجابة غير متوقعة من الخادم (${conn.responseCode})")
            }
            val total = conn.contentLengthLong
            conn.inputStream.use { input ->
                FileOutputStream(out).use { os ->
                    val buf = ByteArray(32 * 1024)
                    var sum = 0L
                    while (true) {
                        val read = input.read(buf)
                        if (read == -1) break
                        os.write(buf, 0, read)
                        sum += read
                        if (total > 0) onFraction((sum.toFloat() / total).coerceIn(0f, 0.99f))
                    }
                }
            }
        } finally {
            conn.disconnect()
        }
    }

    /** يتأكد أن الملف المنزَّل مكتمل: ١١٤ سورة و٦٢٣٦ آية. */
    private fun validate(file: File, edition: Edition) {
        try {
            val root = JSONObject(file.readText())
            if (root.optInt("code") != 200) throw IOException("رد غير صالح من الخادم")
            val surahs = root.getJSONObject("data").getJSONArray("surahs")
            if (surahs.length() != TOTAL_SURAHS) throw IOException("عدد السور غير صحيح")
            var count = 0
            for (i in 0 until surahs.length()) count += surahs.getJSONObject(i).getJSONArray("ayahs").length()
            if (count != TOTAL_AYAHS) throw IOException("عدد الآيات غير صحيح ($count)")
        } catch (e: Exception) {
            file.delete()
            throw IOException("الملف المنزَّل (${edition.label}) غير مكتمل أو تالف. أعد المحاولة.", e)
        }
    }

    private fun readSurahs(f: File): JSONArray =
        JSONObject(f.readText()).getJSONObject("data").getJSONArray("surahs")

    suspend fun load(): Quran = withContext(Dispatchers.Default) {
        val uth = readSurahs(fileOf(EDITIONS[0]))
        val taj = readSurahs(fileOf(EDITIONS[1]))
        val taf = readSurahs(fileOf(EDITIONS[2]))

        val surahs = ArrayList<Surah>(TOTAL_SURAHS)
        for (i in 0 until TOTAL_SURAHS) {
            val su = uth.getJSONObject(i)
            val n = su.getInt("number")
            val au = su.getJSONArray("ayahs")
            val at = taj.getJSONObject(i).getJSONArray("ayahs")
            val af = taf.getJSONObject(i).getJSONArray("ayahs")
            require(au.length() == at.length() && au.length() == af.length()) {
                "عدم تطابق عدد الآيات في السورة $n"
            }

            val list = ArrayList<Ayah>(au.length())
            for (j in 0 until au.length()) {
                val a = au.getJSONObject(j)
                var text = a.getString("text")
                var drop = 0
                // في بعض الإصدارات تُلصق البسملة بأول آية من كل سورة (عدا الفاتحة والتوبة)
                if (n != 1 && n != 9 && j == 0 && ArabicText.startsWithBasmala(text)) {
                    drop = 4
                    text = text.split(" ").drop(drop).joinToString(" ")
                }
                list += Ayah(
                    globalNumber = a.getInt("number"),
                    numberInSurah = a.getInt("numberInSurah"),
                    surahNumber = n,
                    text = text,
                    tajweed = at.getJSONObject(j).getString("text"),
                    tafsir = af.getJSONObject(j).getString("text"),
                    juz = a.getInt("juz"),
                    page = a.optInt("page"),
                    sajda = a.optJSONObject("sajda") != null || a.optBoolean("sajda", false),
                    dropBasmalaWords = drop,
                )
            }

            val fullName = su.getString("name")
            val parts = fullName.split(" ")
            val shortName =
                if (parts.size > 1 && ArabicText.normalize(parts[0]) == "سوره") {
                    parts.drop(1).joinToString(" ")
                } else fullName

            surahs += Surah(
                number = n,
                fullName = fullName,
                shortName = shortName,
                englishName = su.optString("englishName"),
                isMeccan = su.optString("revelationType").equals("Meccan", ignoreCase = true),
                ayahs = list,
            )
        }

        val quran = Quran(surahs)
        require(quran.allAyahs.size == TOTAL_AYAHS) { "عدد الآيات غير مكتمل" }
        quran
    }
}
