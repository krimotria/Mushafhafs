package com.mushaf.hafs

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.mushaf.hafs.data.Quran
import com.mushaf.hafs.ui.BookmarksScreen
import com.mushaf.hafs.ui.IndexScreen
import com.mushaf.hafs.ui.LocalMushafColors
import com.mushaf.hafs.ui.MushafTheme
import com.mushaf.hafs.ui.ReaderScreen
import com.mushaf.hafs.ui.SearchScreen
import com.mushaf.hafs.ui.SettingsScreen
import com.mushaf.hafs.ui.SetupScreen
import com.mushaf.hafs.ui.TajweedScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val vm: AppViewModel = viewModel()
            val mode by vm.prefs.theme.collectAsStateWithLifecycle()
            MushafTheme(mode) {
                val c = LocalMushafColors.current
                Surface(Modifier.fillMaxSize(), color = c.background) {
                    val state by vm.state.collectAsStateWithLifecycle()
                    when (val s = state) {
                        is LoadState.Ready -> AppNav(vm, s.quran)
                        else -> SetupScreen(s, onDownload = vm::download, onRetry = vm::retry)
                    }
                }
            }
        }
    }
}

private sealed interface Screen {
    data object Home : Screen
    data object Search : Screen
    data class Reader(val surah: Int, val ayah: Int) : Screen
}

@Composable
private fun AppNav(vm: AppViewModel, quran: Quran) {
    val stack = remember { mutableStateListOf<Screen>(Screen.Home) }
    var tab by rememberSaveable { mutableIntStateOf(0) }

    fun pop() {
        if (stack.size > 1) stack.removeAt(stack.lastIndex)
    }

    BackHandler(enabled = stack.size > 1) { pop() }

    when (val screen = stack.last()) {
        Screen.Home -> HomeScaffold(
            quran = quran,
            vm = vm,
            tab = tab,
            onTab = { tab = it },
            onOpen = { s, a -> stack.add(Screen.Reader(s, a)) },
            onSearch = { stack.add(Screen.Search) },
        )

        Screen.Search -> SearchScreen(
            quran = quran,
            onBack = ::pop,
            onOpen = { s, a -> stack.add(Screen.Reader(s, a)) },
        )

        is Screen.Reader -> key(screen.surah, screen.ayah) {
            ReaderScreen(
                quran = quran,
                prefs = vm.prefs,
                surahNumber = screen.surah,
                startAyah = screen.ayah,
                onBack = ::pop,
                onOpenSurah = { n -> stack[stack.lastIndex] = Screen.Reader(n, 1) },
            )
        }
    }
}

@Composable
private fun HomeScaffold(
    quran: Quran,
    vm: AppViewModel,
    tab: Int,
    onTab: (Int) -> Unit,
    onOpen: (Int, Int) -> Unit,
    onSearch: () -> Unit,
) {
    val c = LocalMushafColors.current
    val items: List<Pair<String, ImageVector>> = listOf(
        "المصحف" to Icons.Default.MenuBook,
        "العلامات" to Icons.Default.Bookmark,
        "التجويد" to Icons.Default.School,
        "الإعدادات" to Icons.Default.Settings,
    )
    Scaffold(
        containerColor = c.background,
        bottomBar = {
            NavigationBar(containerColor = c.card) {
                items.forEachIndexed { i, (label, icon) ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { onTab(i) },
                        icon = { Icon(icon, contentDescription = label) },
                        label = { Text(label) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = c.primary,
                            selectedTextColor = c.primary,
                            unselectedIconColor = c.subtle,
                            unselectedTextColor = c.subtle,
                            indicatorColor = c.chip,
                        ),
                    )
                }
            }
        },
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> IndexScreen(quran, vm.prefs, onOpen, onSearch)
                1 -> BookmarksScreen(quran, vm.prefs, onOpen)
                2 -> TajweedScreen()
                else -> SettingsScreen(quran, vm.prefs, onRedownload = vm::redownload)
            }
        }
    }
}
