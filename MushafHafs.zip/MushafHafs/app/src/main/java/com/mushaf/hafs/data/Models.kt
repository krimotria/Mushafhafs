package com.mushaf.hafs.data

import androidx.compose.runtime.Immutable

@Immutable
data class Ayah(
    /** رقم الآية في المصحف كله (١..٦٢٣٦) */
    val globalNumber: Int,
    val numberInSurah: Int,
    val surahNumber: Int,
    /** النص العثماني بعد حذف البسملة إن كانت ملصقة بأول السورة */
    val text: String,
    /** نص الآية بترميز أحكام التجويد (قد تسبقه البسملة، انظر dropBasmalaWords) */
    val tajweed: String,
    val tafsir: String,
    val juz: Int,
    val page: Int,
    val sajda: Boolean,
    /** عدد كلمات البسملة التي يجب حذفها من بداية نص التجويد (٠ أو ٤) */
    val dropBasmalaWords: Int,
)

@Immutable
data class Surah(
    val number: Int,
    val fullName: String,
    val shortName: String,
    val englishName: String,
    val isMeccan: Boolean,
    val ayahs: List<Ayah>,
) {
    val typeLabel: String get() = if (isMeccan) "مكية" else "مدنية"

    /** البسملة تُعرض ترويسةً لكل سورة عدا الفاتحة (آية منها) والتوبة (بلا بسملة). */
    val hasBasmalaHeader: Boolean get() = number != 1 && number != 9
}

class Quran(val surahs: List<Surah>) {
    val allAyahs: List<Ayah> = surahs.flatMap { it.ayahs }

    private val normalized: List<String> by lazy { allAyahs.map { ArabicText.normalize(it.text) } }

    val juzStarts: List<Ayah> by lazy {
        allAyahs.groupBy { it.juz }.toSortedMap().map { it.value.first() }
    }

    fun surah(number: Int): Surah = surahs[number - 1]

    fun byGlobal(number: Int): Ayah = allAyahs[number - 1]

    fun search(query: String, limit: Int = 100): List<Ayah> {
        val q = ArabicText.normalize(query)
        if (q.length < 2) return emptyList()
        val out = ArrayList<Ayah>()
        for (i in allAyahs.indices) {
            if (normalized[i].contains(q)) {
                out += allAyahs[i]
                if (out.size >= limit) break
            }
        }
        return out
    }
}
