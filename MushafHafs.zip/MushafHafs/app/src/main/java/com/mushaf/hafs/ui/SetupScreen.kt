package com.mushaf.hafs.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mushaf.hafs.LoadState

@Composable
fun SetupScreen(state: LoadState, onDownload: () -> Unit, onRetry: () -> Unit) {
    val c = LocalMushafColors.current
    Column(
        modifier = Modifier
            .fillMaxSize()
            .systemBarsPadding()
            .padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Icon(Icons.Default.MenuBook, contentDescription = null, tint = c.accent, modifier = Modifier.size(76.dp))
        Spacer(Modifier.height(16.dp))
        Text("المصحف الكامل", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = c.primary)
        Text("برواية حفص عن عاصم", fontSize = 18.sp, color = c.subtle)
        Spacer(Modifier.height(36.dp))

        when (state) {
            LoadState.NeedsDownload -> {
                Text(
                    "لتتمكن من القراءة دون إنترنت لاحقاً، يلزم تنزيل نص المصحف وتفسير الميسر وبيانات أحكام التجويد مرة واحدة فقط.",
                    textAlign = TextAlign.Center,
                    color = c.text,
                    fontSize = 17.sp,
                    lineHeight = 28.sp,
                )
                Spacer(Modifier.height(24.dp))
                Button(onClick = onDownload, modifier = Modifier.fillMaxWidth()) {
                    Text("تنزيل المصحف والتفسير", fontSize = 17.sp, modifier = Modifier.padding(vertical = 6.dp))
                }
            }

            is LoadState.Downloading -> {
                LinearProgressIndicator(progress = { state.progress }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(14.dp))
                Text(
                    "${state.label} … ${(state.progress * 100).toInt()}٪".replace(Regex("[0-9]")) {
                        ('٠' + (it.value[0] - '0')).toString()
                    },
                    color = c.text,
                    fontSize = 16.sp,
                )
            }

            LoadState.Loading -> {
                CircularProgressIndicator(color = c.primary)
                Spacer(Modifier.height(14.dp))
                Text("جاري تجهيز المصحف…", color = c.text, fontSize = 16.sp)
            }

            is LoadState.Error -> {
                Text(
                    state.message,
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.error,
                    fontSize = 16.sp,
                    lineHeight = 26.sp,
                )
                Spacer(Modifier.height(20.dp))
                Button(onClick = onRetry, modifier = Modifier.fillMaxWidth()) {
                    Text("إعادة المحاولة", fontSize = 17.sp, modifier = Modifier.padding(vertical = 6.dp))
                }
            }

            is LoadState.Ready -> Unit
        }
    }
}
