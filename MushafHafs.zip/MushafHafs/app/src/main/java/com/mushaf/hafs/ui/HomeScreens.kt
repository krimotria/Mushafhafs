package com.mushaf.hafs.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.mushaf.hafs.data.Prefs
import com.mushaf.hafs.data.Quran
import com.mushaf.hafs.data.toArabicDigits

/** زر اختيار بسيط على شكل حبة (بديل عن المكونات التجريبية). */
@Composable
fun Pill(label: String, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val c = LocalMushafColors.current
    Surface(
        onClick = onClick,
        modifier = modifier,
        shape = RoundedCornerShape(50),
        color = if (selected) c.primary else c.card,
        contentColor = if (selected) c.onPrimary else c.text,
        border = BorderStroke(1.dp, if (selected) c.primary else c.divider),
    ) {
        Text(
            label,
            modifier = Modifier.padding(horizontal = 18.dp, vertical = 9.dp),
            fontSize = 15.sp,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
            textAlign = TextAlign.Center,
        )
    }
}

@Composable
fun NumberBadge(number: Int, size: Int = 42) {
    val c = LocalMushafColors.current
    Box(
        modifier = Modifier
            .size(size.dp)
            .clip(CircleShape)
            .border(1.2.dp, c.accent, CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        Text(number.toArabicDigits(), color = c.primary, fontSize = 15.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun IndexScreen(
    quran: Quran,
    prefs: Prefs,
    onOpen: (surah: Int, ayah: Int) -> Unit,
    onSearch: () -> Unit,
) {
    val c = LocalMushafColors.current
    var mode by rememberSaveable { mutableIntStateOf(0) }
    val last by prefs.lastRead.collectAsStateWithLifecycle()

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(start = 20.dp, end = 8.dp, top = 12.dp, bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "المصحف الكامل",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        color = c.primary,
                    )
                    Text("برواية حفص عن عاصم", style = MaterialTheme.typography.bodyMedium, color = c.subtle)
                }
                IconButton(onClick = onSearch) {
                    Icon(Icons.Default.Search, contentDescription = "بحث", tint = c.text)
                }
            }
        }

        if (last in 1..quran.allAyahs.size) {
            item {
                val ayah = quran.byGlobal(last)
                val surah = quran.surah(ayah.surahNumber)
                Surface(
                    onClick = { onOpen(ayah.surahNumber, ayah.numberInSurah) },
                    shape = RoundedCornerShape(18.dp),
                    color = c.primary,
                    contentColor = c.onPrimary,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 8.dp),
                ) {
                    Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.MenuBook, null, modifier = Modifier.size(30.dp))
                        Spacer(Modifier.width(14.dp))
                        Column {
                            Text("متابعة القراءة", fontSize = 13.sp)
                            Text(
                                "سورة ${surah.shortName} • الآية ${ayah.numberInSurah.toArabicDigits()}",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                            )
                        }
                    }
                }
            }
        }

        item {
            Row(
                Modifier.padding(horizontal = 20.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Pill("السور", mode == 0, { mode = 0 })
                Pill("الأجزاء", mode == 1, { mode = 1 })
            }
        }

        if (mode == 0) {
            items(quran.surahs, key = { it.number }) { s ->
                Column(Modifier.clickable { onOpen(s.number, 1) }) {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        NumberBadge(s.number)
                        Spacer(Modifier.width(16.dp))
                        Column(Modifier.weight(1f)) {
                            Text(s.shortName, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, color = c.text)
                            Text(
                                "${s.typeLabel} • ${s.ayahs.size.toArabicDigits()} آية",
                                fontSize = 13.sp,
                                color = c.subtle,
                            )
                        }
                        Text(
                            "ص ${s.ayahs.first().page.toArabicDigits()}",
                            fontSize = 13.sp,
                            color = c.subtle,
                        )
                    }
                    HorizontalDivider(color = c.divider, modifier = Modifier.padding(horizontal = 20.dp))
                }
            }
        } else {
            items(quran.juzStarts, key = { it.juz }) { a ->
                val s = quran.surah(a.surahNumber)
                Column(Modifier.clickable { onOpen(a.surahNumber, a.numberInSurah) }) {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        NumberBadge(a.juz)
                        Spacer(Modifier.width(16.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                "الجزء ${a.juz.toArabicDigits()}",
                                fontSize = 19.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = c.text,
                            )
                            Text(
                                "تبدأ من سورة ${s.shortName} – الآية ${a.numberInSurah.toArabicDigits()}",
                                fontSize = 13.sp,
                                color = c.subtle,
                            )
                        }
                    }
                    HorizontalDivider(color = c.divider, modifier = Modifier.padding(horizontal = 20.dp))
                }
            }
        }
    }
}

@Composable
fun BookmarksScreen(
    quran: Quran,
    prefs: Prefs,
    onOpen: (surah: Int, ayah: Int) -> Unit,
) {
    val c = LocalMushafColors.current
    val bookmarks by prefs.bookmarks.collectAsStateWithLifecycle()
    val items = bookmarks.filter { it in 1..quran.allAyahs.size }.sorted().map { quran.byGlobal(it) }

    Column(Modifier.fillMaxSize()) {
        Text(
            "العلامات المرجعية",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            color = c.primary,
            modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 8.dp),
        )
        if (items.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Bookmark, null, tint = c.divider, modifier = Modifier.size(64.dp))
                    Spacer(Modifier.height(12.dp))
                    Text(
                        "لا توجد علامات بعد.\nاضغط على أي آية أثناء القراءة ثم اختر «علامة مرجعية».",
                        color = c.subtle,
                        textAlign = TextAlign.Center,
                        lineHeight = 26.sp,
                    )
                }
            }
        } else {
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
                items(items, key = { it.globalNumber }) { a ->
                    val s = quran.surah(a.surahNumber)
                    Column(Modifier.clickable { onOpen(a.surahNumber, a.numberInSurah) }) {
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .padding(start = 20.dp, end = 8.dp, top = 10.dp, bottom = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(
                                    "سورة ${s.shortName} • الآية ${a.numberInSurah.toArabicDigits()}",
                                    fontWeight = FontWeight.SemiBold,
                                    color = c.primary,
                                    fontSize = 16.sp,
                                )
                                Text(
                                    a.text,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis,
                                    color = c.text,
                                    fontSize = 17.sp,
                                    lineHeight = 28.sp,
                                )
                            }
                            IconButton(onClick = { prefs.toggleBookmark(a.globalNumber) }) {
                                Icon(Icons.Default.Delete, contentDescription = "حذف العلامة", tint = c.subtle)
                            }
                        }
                        HorizontalDivider(color = c.divider, modifier = Modifier.padding(horizontal = 20.dp))
                    }
                }
            }
        }
    }
}
