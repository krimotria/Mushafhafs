package com.mushaf.hafs.data

/**
 * محلل ترميز أحكام التجويد القادم من Al Quran Cloud (إصدار quran-tajweed).
 * الصيغة: [رمز:رقم[حروف]  أو  [رمز[حروف]  مثال: [h:9421[ٱ]
 */
object Tajweed {
    data class Segment(val text: String, val rule: Char?)

    private val pattern = Regex("""\[([a-z])(?::\d+)?\[([^\]]*)]""")

    fun parse(markup: String): List<Segment> {
        val out = ArrayList<Segment>()
        var last = 0
        for (m in pattern.findAll(markup)) {
            if (m.range.first > last) out += Segment(markup.substring(last, m.range.first), null)
            out += Segment(m.groupValues[2], m.groupValues[1][0])
            last = m.range.last + 1
        }
        if (last < markup.length) out += Segment(markup.substring(last), null)
        return out
    }

    /** حذف أول [words] كلمات (البسملة الملصقة بأول السورة) مع الحفاظ على الترميز. */
    fun dropFirstWords(segments: List<Segment>, words: Int): List<Segment> {
        var remaining = words
        val out = ArrayList<Segment>()
        for (seg in segments) {
            val kept = StringBuilder()
            for (ch in seg.text) {
                if (remaining > 0) {
                    if (ch.isWhitespace()) remaining--
                    continue
                }
                kept.append(ch)
            }
            if (kept.isNotEmpty()) out += Segment(kept.toString(), seg.rule)
        }
        return out
    }
}
