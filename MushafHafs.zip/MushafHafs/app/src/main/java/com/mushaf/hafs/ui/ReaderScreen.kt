package com.mushaf.hafs.ui

import android.content.Intent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.FormatListNumbered
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.mushaf.hafs.data.Ayah
import com.mushaf.hafs.data.Prefs
import com.mushaf.hafs.data.Quran
import com.mushaf.hafs.data.Surah
import com.mushaf.hafs.data.toArabicDigits
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReaderScreen(
    quran: Quran,
    prefs: Prefs,
    surahNumber: Int,
    startAyah: Int,
    onBack: () -> Unit,
    onOpenSurah: (Int) -> Unit,
) {
    val surah = quran.surah(surahNumber)
    val c = LocalMushafColors.current
    val fontSize by prefs.fontSize.collectAsStateWithLifecycle()
    val spacing by prefs.lineSpacing.collectAsStateWithLifecycle()
    val tajweedOn by prefs.tajweedColors.collectAsStateWithLifecycle()
    val keepOn by prefs.keepScreenOn.collectAsStateWithLifecycle()
    val bookmarks by prefs.bookmarks.collectAsStateWithLifecycle()
    val quranFont = rememberQuranFont()
    val scope = rememberCoroutineScope()

    // الفهرس ٠ للترويسة، والآية n في الفهرس n
    val initialIndex = if (startAyah <= 1) 0 else startAyah.coerceAtMost(surah.ayahs.size)
    val listState = rememberLazyListState(initialFirstVisibleItemIndex = initialIndex)
    var selected by remember { mutableStateOf<Ayah?>(null) }
    var showJump by remember { mutableStateOf(false) }

    val view = LocalView.current
    DisposableEffect(keepOn) {
        view.keepScreenOn = keepOn
        onDispose { view.keepScreenOn = false }
    }

    LaunchedEffect(listState) {
        snapshotFlow { listState.firstVisibleItemIndex }.collect { idx ->
            val ayah = surah.ayahs.getOrNull((idx - 1).coerceAtLeast(0))
            if (ayah != null) prefs.setLastRead(ayah.globalNumber)
        }
    }

    Scaffold(
        containerColor = c.background,
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(surah.fullName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(
                            "الجزء ${surah.ayahs.first().juz.toArabicDigits()} • ${surah.typeLabel} • ${surah.ayahs.size.toArabicDigits()} آية",
                            style = MaterialTheme.typography.labelSmall,
                            color = c.subtle,
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                    }
                },
                actions = {
                    IconButton(onClick = { showJump = true }) {
                        Icon(Icons.Default.FormatListNumbered, contentDescription = "انتقال إلى آية")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = c.background,
                    titleContentColor = c.text,
                    navigationIconContentColor = c.text,
                    actionIconContentColor = c.text,
                ),
            )
        },
    ) { pad ->
        LazyColumn(
            state = listState,
            modifier = Modifier
                .padding(pad)
                .fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
        ) {
            item(key = "header") {
                SurahBanner(surah, quranFont, basmala = quran.surah(1).ayahs.first().text)
            }
            items(surah.ayahs, key = { it.globalNumber }) { ayah ->
                AyahItem(
                    ayah = ayah,
                    fontSize = fontSize,
                    spacing = spacing,
                    tajweedOn = tajweedOn,
                    bookmarked = ayah.globalNumber in bookmarks,
                    font = quranFont,
                    onClick = { selected = ayah },
                )
            }
            item(key = "footer") {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(vertical = 24.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    if (surahNumber > 1) {
                        TextButton(onClick = { onOpenSurah(surahNumber - 1) }) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(quran.surah(surahNumber - 1).shortName)
                        }
                    } else Spacer(Modifier.width(1.dp))
                    if (surahNumber < 114) {
                        TextButton(onClick = { onOpenSurah(surahNumber + 1) }) {
                            Text(quran.surah(surahNumber + 1).shortName)
                            Spacer(Modifier.width(6.dp))
                            Icon(Icons.AutoMirrored.Filled.ArrowForward, null, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }
        }
    }

    selected?.let { ayah ->
        AyahSheet(
            surah = surah,
            ayah = ayah,
            bookmarked = ayah.globalNumber in bookmarks,
            font = quranFont,
            fontSize = fontSize,
            tajweedOn = tajweedOn,
            onToggleBookmark = { prefs.toggleBookmark(ayah.globalNumber) },
            onDismiss = { selected = null },
        )
    }

    if (showJump) {
        var input by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showJump = false },
            title = { Text("الانتقال إلى آية") },
            text = {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it.filter(Char::isDigit).take(3) },
                    label = { Text("رقم الآية (١ – ${surah.ayahs.size.toArabicDigits()})") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number),
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    val n = input.toIntOrNull()
                    if (n != null) {
                        scope.launch { listState.scrollToItem(n.coerceIn(1, surah.ayahs.size)) }
                    }
                    showJump = false
                }) { Text("انتقال") }
            },
            dismissButton = { TextButton(onClick = { showJump = false }) { Text("إلغاء") } },
            containerColor = c.card,
        )
    }
}

@Composable
private fun SurahBanner(surah: Surah, font: FontFamily, basmala: String) {
    val c = LocalMushafColors.current
    Column(
        Modifier
            .fillMaxWidth()
            .padding(top = 8.dp, bottom = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = c.card,
            border = BorderStroke(1.2.dp, c.accent),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Column(Modifier.padding(vertical = 18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    surah.fullName,
                    fontFamily = font,
                    fontSize = 30.sp,
                    fontWeight = FontWeight.Bold,
                    color = c.primary,
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    "${surah.typeLabel} • ${surah.ayahs.size.toArabicDigits()} آية",
                    fontSize = 14.sp,
                    color = c.subtle,
                )
            }
        }
        if (surah.hasBasmalaHeader) {
            Spacer(Modifier.height(18.dp))
            Text(
                basmala,
                fontFamily = font,
                fontSize = 28.sp,
                color = c.text,
                textAlign = TextAlign.Center,
            )
        }
    }
}

@Composable
private fun AyahItem(
    ayah: Ayah,
    fontSize: Float,
    spacing: Float,
    tajweedOn: Boolean,
    bookmarked: Boolean,
    font: FontFamily,
    onClick: () -> Unit,
) {
    val c = LocalMushafColors.current
    val annotated = remember(ayah.globalNumber, tajweedOn, c.dark, c.accent) {
        buildAyahText(ayah, tajweedOn, c)
    }
    Column(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(top = 14.dp),
    ) {
        Text(
            text = annotated,
            style = TextStyle(
                fontFamily = font,
                fontSize = fontSize.sp,
                lineHeight = (fontSize * spacing).sp,
                color = c.text,
                textDirection = TextDirection.Rtl,
                textAlign = TextAlign.Justify,
            ),
            modifier = Modifier.fillMaxWidth(),
        )
        if (ayah.sajda || bookmarked) {
            Row(Modifier.padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                if (bookmarked) {
                    Icon(Icons.Default.Bookmark, null, tint = c.accent, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(10.dp))
                }
                if (ayah.sajda) {
                    Text("۩ موضع سجدة", color = c.accent, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
        Spacer(Modifier.height(14.dp))
        HorizontalDivider(color = c.divider)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AyahSheet(
    surah: Surah,
    ayah: Ayah,
    bookmarked: Boolean,
    font: FontFamily,
    fontSize: Float,
    tajweedOn: Boolean,
    onToggleBookmark: () -> Unit,
    onDismiss: () -> Unit,
) {
    val c = LocalMushafColors.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val clipboard = LocalClipboardManager.current
    val context = LocalContext.current
    val verse = remember(ayah.globalNumber, tajweedOn, c.dark, c.accent) { buildAyahText(ayah, tajweedOn, c) }

    val shareText = buildString {
        append(ayah.text)
        append(" ﴿${ayah.numberInSurah.toArabicDigits()}﴾\n")
        append("[سورة ${surah.shortName} – الآية ${ayah.numberInSurah.toArabicDigits()}]\n\n")
        append("التفسير الميسر:\n${ayah.tafsir}")
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = c.card,
        contentColor = c.text,
    ) {
        Column(
            Modifier
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 22.dp)
                .padding(bottom = 36.dp),
        ) {
            Text(
                "سورة ${surah.shortName} • الآية ${ayah.numberInSurah.toArabicDigits()}",
                style = MaterialTheme.typography.titleMedium,
                color = c.primary,
                fontWeight = FontWeight.Bold,
            )
            Spacer(Modifier.height(14.dp))
            Text(
                verse,
                style = TextStyle(
                    fontFamily = font,
                    fontSize = (fontSize * 0.9f).sp,
                    lineHeight = (fontSize * 1.9f).sp,
                    color = c.text,
                    textDirection = TextDirection.Rtl,
                ),
            )
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                TextButton(onClick = onToggleBookmark) {
                    Icon(
                        if (bookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                        null,
                        modifier = Modifier.size(20.dp),
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(if (bookmarked) "إزالة العلامة" else "علامة مرجعية")
                }
                TextButton(onClick = { clipboard.setText(AnnotatedString(shareText)) }) {
                    Icon(Icons.Default.ContentCopy, null, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("نسخ")
                }
                TextButton(onClick = {
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, shareText)
                    }
                    context.startActivity(Intent.createChooser(send, "مشاركة الآية"))
                }) {
                    Icon(Icons.Default.Share, null, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("مشاركة")
                }
            }
            HorizontalDivider(color = c.divider, modifier = Modifier.padding(vertical = 10.dp))
            Text(
                "التفسير الميسر",
                style = MaterialTheme.typography.titleSmall,
                color = c.accent,
                fontWeight = FontWeight.Bold,
            )
            Spacer(Modifier.height(8.dp))
            Text(
                ayah.tafsir,
                fontSize = 19.sp,
                lineHeight = 33.sp,
                color = c.text,
            )
        }
    }
}
