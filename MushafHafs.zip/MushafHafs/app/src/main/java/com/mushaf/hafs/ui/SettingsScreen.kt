package com.mushaf.hafs.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.mushaf.hafs.data.Prefs
import com.mushaf.hafs.data.Quran
import com.mushaf.hafs.data.ThemeMode
import com.mushaf.hafs.data.toArabicDigits

@Composable
fun SettingsScreen(quran: Quran, prefs: Prefs, onRedownload: () -> Unit) {
    val c = LocalMushafColors.current
    val theme by prefs.theme.collectAsStateWithLifecycle()
    val fontSize by prefs.fontSize.collectAsStateWithLifecycle()
    val spacing by prefs.lineSpacing.collectAsStateWithLifecycle()
    val tajweedOn by prefs.tajweedColors.collectAsStateWithLifecycle()
    val keepOn by prefs.keepScreenOn.collectAsStateWithLifecycle()
    val font = rememberQuranFont()
    var confirmRedownload by remember { mutableStateOf(false) }

    // معاينة من نص المصحف المحمَّل نفسه (الآية الثانية من الفاتحة)
    val sample = quran.surah(1).ayahs[1]
    val sampleText = remember(sample.globalNumber, tajweedOn, c.dark, c.accent) { buildAyahText(sample, tajweedOn, c) }

    Column(
        Modifier
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
    ) {
        Text(
            "الإعدادات",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            color = c.primary,
        )

        Section("المظهر")
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            ThemeMode.entries.forEach { m -> Pill(m.label, theme == m, { prefs.setTheme(m) }) }
        }

        Section("معاينة القراءة")
        Text(
            sampleText,
            style = TextStyle(
                fontFamily = font,
                fontSize = fontSize.sp,
                lineHeight = (fontSize * spacing).sp,
                color = c.text,
                textDirection = TextDirection.Rtl,
                textAlign = TextAlign.Start,
            ),
            modifier = Modifier.fillMaxWidth(),
        )

        Section("حجم الخط: ${fontSize.toInt().toArabicDigits()}")
        Slider(
            value = fontSize,
            onValueChange = { prefs.setFontSize(it) },
            valueRange = 20f..48f,
            colors = SliderDefaults.colors(thumbColor = c.primary, activeTrackColor = c.primary),
        )

        Section("تباعد الأسطر")
        Slider(
            value = spacing,
            onValueChange = { prefs.setLineSpacing(it) },
            valueRange = 1.4f..2.6f,
            colors = SliderDefaults.colors(thumbColor = c.primary, activeTrackColor = c.primary),
        )

        HorizontalDivider(color = c.divider, modifier = Modifier.padding(vertical = 12.dp))

        ToggleRow("تلوين أحكام التجويد", "تلوين الغنة والمدود والإدغام والإخفاء والقلقلة وغيرها", tajweedOn) {
            prefs.setTajweedColors(it)
        }
        ToggleRow("إبقاء الشاشة مضيئة", "أثناء القراءة في المصحف", keepOn) { prefs.setKeepScreenOn(it) }

        HorizontalDivider(color = c.divider, modifier = Modifier.padding(vertical = 12.dp))

        Section("البيانات")
        OutlinedButton(onClick = { confirmRedownload = true }, modifier = Modifier.fillMaxWidth()) {
            Text("إعادة تنزيل نص المصحف والتفسير")
        }

        Section("عن التطبيق")
        Text(
            "المصحف الكامل برواية حفص عن عاصم، مع التفسير الميسر وأحكام التجويد.\n" +
                "المصدر: نص القرآن العثماني وترميز التجويد والتفسير الميسر من واجهة Al Quran Cloud (alquran.cloud)، وتُخزَّن على جهازك بعد أول تنزيل.\n" +
                "الإصدار ١٫٠",
            color = c.subtle,
            fontSize = 14.sp,
            lineHeight = 24.sp,
        )
        Spacer(Modifier.height(24.dp))
    }

    if (confirmRedownload) {
        AlertDialog(
            onDismissRequest = { confirmRedownload = false },
            title = { Text("إعادة التنزيل") },
            text = { Text("سيُحذف النص المخزَّن ويُنزَّل من جديد. يلزم اتصال بالإنترنت. المتابعة؟") },
            confirmButton = {
                TextButton(onClick = {
                    confirmRedownload = false
                    onRedownload()
                }) { Text("متابعة") }
            },
            dismissButton = { TextButton(onClick = { confirmRedownload = false }) { Text("إلغاء") } },
            containerColor = c.card,
        )
    }
}

@Composable
private fun Section(title: String) {
    val c = LocalMushafColors.current
    Text(
        title,
        color = c.accent,
        fontWeight = FontWeight.Bold,
        fontSize = 16.sp,
        modifier = Modifier.padding(top = 20.dp, bottom = 8.dp),
    )
}

@Composable
private fun ToggleRow(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    val c = LocalMushafColors.current
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = c.text, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = c.subtle, fontSize = 13.sp)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
