package com.mushaf.hafs.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mushaf.hafs.data.TajweedRules

@Composable
fun TajweedScreen() {
    val c = LocalMushafColors.current
    val font = rememberQuranFont()

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 32.dp)) {
        item {
            Column(Modifier.padding(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 8.dp)) {
                Text(
                    "أحكام التجويد",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = c.primary,
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    "هذه الألوان هي نفسها المستخدمة في المصحف عند تفعيل «تلوين أحكام التجويد» من الإعدادات. التلوين آلي وهو عونٌ على الفهم، ولا يُغني عن التلقي من معلّم متقن.",
                    color = c.subtle,
                    fontSize = 15.sp,
                    lineHeight = 25.sp,
                )
            }
        }

        TajweedRules.groups.forEach { group ->
            item(key = "g_$group") {
                Text(
                    group,
                    color = c.accent,
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp,
                    modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 22.dp, bottom = 8.dp),
                )
            }
            val rules = TajweedRules.all.filter { it.group == group }
            rules.forEachIndexed { i, rule ->
                item(key = "r_${group}_$i") {
                    val color = Color(if (c.dark) rule.dark else rule.light)
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = c.card,
                        border = BorderStroke(1.dp, c.divider),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp, vertical = 5.dp),
                    ) {
                        Column(Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                if (rule.code != null) {
                                    Box(
                                        Modifier
                                            .size(16.dp)
                                            .background(color, CircleShape),
                                    )
                                } else {
                                    Box(
                                        Modifier
                                            .size(16.dp)
                                            .border(1.5.dp, c.subtle, CircleShape),
                                    )
                                }
                                Spacer(Modifier.width(10.dp))
                                Text(rule.name, fontWeight = FontWeight.Bold, fontSize = 18.sp, color = c.text)
                            }
                            Spacer(Modifier.height(8.dp))
                            Text(rule.description, color = c.text, fontSize = 16.sp, lineHeight = 27.sp)
                            Spacer(Modifier.height(10.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("مثال:", color = c.subtle, fontSize = 14.sp)
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    rule.example,
                                    fontFamily = font,
                                    fontSize = 26.sp,
                                    color = if (rule.code != null) color else c.text,
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
