package com.mushaf.hafs.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class ThemeMode(val label: String) {
    PAPER("ورقي"),
    LIGHT("فاتح"),
    DARK("داكن"),
}

class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("mushaf_prefs", Context.MODE_PRIVATE)

    private val _theme = MutableStateFlow(readTheme())
    val theme: StateFlow<ThemeMode> = _theme.asStateFlow()

    private val _fontSize = MutableStateFlow(sp.getFloat("fontSize", 28f))
    val fontSize: StateFlow<Float> = _fontSize.asStateFlow()

    private val _lineSpacing = MutableStateFlow(sp.getFloat("lineSpacing", 2.0f))
    val lineSpacing: StateFlow<Float> = _lineSpacing.asStateFlow()

    private val _tajweedColors = MutableStateFlow(sp.getBoolean("tajweedColors", true))
    val tajweedColors: StateFlow<Boolean> = _tajweedColors.asStateFlow()

    private val _keepScreenOn = MutableStateFlow(sp.getBoolean("keepScreenOn", true))
    val keepScreenOn: StateFlow<Boolean> = _keepScreenOn.asStateFlow()

    private val _bookmarks = MutableStateFlow(readBookmarks())
    val bookmarks: StateFlow<Set<Int>> = _bookmarks.asStateFlow()

    private val _lastRead = MutableStateFlow(sp.getInt("lastRead", 0))
    val lastRead: StateFlow<Int> = _lastRead.asStateFlow()

    private fun readTheme(): ThemeMode =
        try {
            ThemeMode.valueOf(sp.getString("theme", ThemeMode.PAPER.name) ?: ThemeMode.PAPER.name)
        } catch (e: IllegalArgumentException) {
            ThemeMode.PAPER
        }

    private fun readBookmarks(): Set<Int> =
        (sp.getStringSet("bookmarks", emptySet()) ?: emptySet()).mapNotNull { it.toIntOrNull() }.toSet()

    fun setTheme(mode: ThemeMode) {
        _theme.value = mode
        sp.edit().putString("theme", mode.name).apply()
    }

    fun setFontSize(v: Float) {
        _fontSize.value = v
        sp.edit().putFloat("fontSize", v).apply()
    }

    fun setLineSpacing(v: Float) {
        _lineSpacing.value = v
        sp.edit().putFloat("lineSpacing", v).apply()
    }

    fun setTajweedColors(v: Boolean) {
        _tajweedColors.value = v
        sp.edit().putBoolean("tajweedColors", v).apply()
    }

    fun setKeepScreenOn(v: Boolean) {
        _keepScreenOn.value = v
        sp.edit().putBoolean("keepScreenOn", v).apply()
    }

    fun toggleBookmark(globalNumber: Int) {
        val set = _bookmarks.value.toMutableSet()
        if (!set.add(globalNumber)) set.remove(globalNumber)
        _bookmarks.value = set
        sp.edit().putStringSet("bookmarks", set.map { it.toString() }.toSet()).apply()
    }

    fun setLastRead(globalNumber: Int) {
        if (_lastRead.value == globalNumber) return
        _lastRead.value = globalNumber
        sp.edit().putInt("lastRead", globalNumber).apply()
    }
}
