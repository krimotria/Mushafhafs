package com.mushaf.hafs.data

object ArabicText {
    private const val BASMALA_NORMALIZED = "بسماللهالرحمنالرحيم"

    /** تبسيط النص العربي للبحث: حذف التشكيل وتوحيد الألف والياء والتاء المربوطة. */
    fun normalize(input: String): String {
        val sb = StringBuilder(input.length)
        for (ch in input) {
            val c = when (ch) {
                'ٱ', 'آ', 'أ', 'إ' -> 'ا'
                'ى', 'ئ' -> 'ي'
                'ة' -> 'ه'
                'ؤ' -> 'و'
                else -> ch
            }
            if (c == ' ' || (c in 'ء'..'ي' && c != 'ـ')) sb.append(c)
        }
        return sb.toString().trim()
    }

    fun startsWithBasmala(text: String): Boolean =
        normalize(text).replace(" ", "").startsWith(BASMALA_NORMALIZED)
}

fun Int.toArabicDigits(): String =
    toString().map { if (it in '0'..'9') '٠' + (it - '0') else it }.joinToString("")
