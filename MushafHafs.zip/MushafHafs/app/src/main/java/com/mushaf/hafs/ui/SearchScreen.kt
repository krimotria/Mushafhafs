package com.mushaf.hafs.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mushaf.hafs.data.Quran
import com.mushaf.hafs.data.toArabicDigits

@Composable
fun SearchScreen(
    quran: Quran,
    onBack: () -> Unit,
    onOpen: (surah: Int, ayah: Int) -> Unit,
) {
    val c = LocalMushafColors.current
    var query by remember { mutableStateOf("") }
    val results = remember(query) { quran.search(query) }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { focus.requestFocus() }

    Column(
        Modifier
            .fillMaxSize()
            .systemBarsPadding()
            .imePadding(),
    ) {
        Row(Modifier.padding(horizontal = 8.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع", tint = c.text)
            }
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                placeholder = { Text("ابحث في نص القرآن…") },
                singleLine = true,
                modifier = Modifier
                    .weight(1f)
                    .focusRequester(focus),
            )
        }

        val hint = when {
            query.isBlank() -> "اكتب كلمتين على الأقل. البحث لا يتأثر بالتشكيل."
            ArabicTextLength(query) < 2 -> "اكتب حرفين على الأقل."
            results.isEmpty() -> "لا نتائج مطابقة."
            else -> "${results.size.toArabicDigits()} نتيجة${if (results.size >= 100) " (أول ١٠٠)" else ""}"
        }
        Text(hint, color = c.subtle, fontSize = 14.sp, modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp))

        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
            items(results, key = { it.globalNumber }) { a ->
                val s = quran.surah(a.surahNumber)
                Column(Modifier.clickable { onOpen(a.surahNumber, a.numberInSurah) }) {
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp, vertical = 10.dp),
                    ) {
                        Text(
                            "سورة ${s.shortName} • الآية ${a.numberInSurah.toArabicDigits()}",
                            color = c.primary,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 15.sp,
                        )
                        Text(
                            a.text,
                            color = c.text,
                            fontSize = 18.sp,
                            lineHeight = 30.sp,
                            maxLines = 3,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                    HorizontalDivider(color = c.divider, modifier = Modifier.padding(horizontal = 20.dp))
                }
            }
        }
    }
}

private fun ArabicTextLength(q: String): Int = com.mushaf.hafs.data.ArabicText.normalize(q).length
