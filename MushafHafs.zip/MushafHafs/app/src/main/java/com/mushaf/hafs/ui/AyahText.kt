package com.mushaf.hafs.ui

import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import com.mushaf.hafs.data.Ayah
import com.mushaf.hafs.data.Tajweed
import com.mushaf.hafs.data.TajweedRules
import com.mushaf.hafs.data.toArabicDigits

/** نص الآية ملوّناً بأحكام التجويد (اختيارياً) وفي آخره علامة نهاية الآية ﴿٣﴾ */
fun buildAyahText(ayah: Ayah, tajweedOn: Boolean, c: MushafColors, withMarker: Boolean = true): AnnotatedString =
    buildAnnotatedString {
        var segments = if (tajweedOn) Tajweed.parse(ayah.tajweed) else emptyList()
        if (segments.isNotEmpty() && ayah.dropBasmalaWords > 0) {
            segments = Tajweed.dropFirstWords(segments, ayah.dropBasmalaWords)
        }
        if (segments.isEmpty()) {
            append(ayah.text)
        } else {
            for (s in segments) {
                val color = s.rule?.let { TajweedRules.color(it, c.dark) }
                if (color != null) {
                    withStyle(SpanStyle(color = color)) { append(s.text) }
                } else {
                    append(s.text)
                }
            }
        }
        if (withMarker) {
            append(" ")
            withStyle(SpanStyle(color = c.accent)) {
                append("﴿${ayah.numberInSurah.toArabicDigits()}﴾")
            }
        }
    }
