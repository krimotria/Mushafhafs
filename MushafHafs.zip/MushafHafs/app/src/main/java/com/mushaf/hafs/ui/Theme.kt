package com.mushaf.hafs.ui

import android.app.Activity
import android.graphics.Typeface
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.LayoutDirection
import androidx.core.view.WindowCompat
import com.mushaf.hafs.data.ThemeMode

data class MushafColors(
    val background: Color,
    val card: Color,
    val chip: Color,
    val text: Color,
    val subtle: Color,
    val primary: Color,
    val onPrimary: Color,
    val accent: Color,
    val divider: Color,
    val dark: Boolean,
)

private val PaperColors = MushafColors(
    background = Color(0xFFF8F1E1),
    card = Color(0xFFFFFBF0),
    chip = Color(0xFFE3EDDF),
    text = Color(0xFF2B2823),
    subtle = Color(0xFF7A7264),
    primary = Color(0xFF1F6F5C),
    onPrimary = Color.White,
    accent = Color(0xFFB8862B),
    divider = Color(0xFFE6DCC3),
    dark = false,
)

private val LightColors = MushafColors(
    background = Color(0xFFFFFFFF),
    card = Color(0xFFF6F7F5),
    chip = Color(0xFFDDEDE6),
    text = Color(0xFF1E1F1D),
    subtle = Color(0xFF6B6F68),
    primary = Color(0xFF1F6F5C),
    onPrimary = Color.White,
    accent = Color(0xFFB8862B),
    divider = Color(0xFFE3E5E0),
    dark = false,
)

private val DarkColors = MushafColors(
    background = Color(0xFF111513),
    card = Color(0xFF1B211E),
    chip = Color(0xFF24423A),
    text = Color(0xFFE9E5D8),
    subtle = Color(0xFF9AA39B),
    primary = Color(0xFF59C2A6),
    onPrimary = Color(0xFF06241C),
    accent = Color(0xFFE0B965),
    divider = Color(0xFF2C3530),
    dark = true,
)

val LocalMushafColors = staticCompositionLocalOf { PaperColors }

@Composable
fun MushafTheme(mode: ThemeMode, content: @Composable () -> Unit) {
    val c = when (mode) {
        ThemeMode.PAPER -> PaperColors
        ThemeMode.LIGHT -> LightColors
        ThemeMode.DARK -> DarkColors
    }
    val scheme = if (c.dark) {
        darkColorScheme(
            primary = c.primary, onPrimary = c.onPrimary,
            background = c.background, onBackground = c.text,
            surface = c.background, onSurface = c.text,
            surfaceVariant = c.card, onSurfaceVariant = c.subtle,
            secondaryContainer = c.chip, onSecondaryContainer = c.text,
            surfaceContainerLow = c.card, surfaceContainer = c.card,
            surfaceContainerHigh = c.card, surfaceContainerHighest = c.card,
            outline = c.divider, outlineVariant = c.divider,
        )
    } else {
        lightColorScheme(
            primary = c.primary, onPrimary = c.onPrimary,
            background = c.background, onBackground = c.text,
            surface = c.background, onSurface = c.text,
            surfaceVariant = c.card, onSurfaceVariant = c.subtle,
            secondaryContainer = c.chip, onSecondaryContainer = c.text,
            surfaceContainerLow = c.card, surfaceContainer = c.card,
            surfaceContainerHigh = c.card, surfaceContainerHighest = c.card,
            outline = c.divider, outlineVariant = c.divider,
        )
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                val controller = WindowCompat.getInsetsController(window, view)
                controller.isAppearanceLightStatusBars = !c.dark
                controller.isAppearanceLightNavigationBars = !c.dark
            }
        }
    }

    // التطبيق عربي بالكامل: نفرض اتجاه اليمين لليسار بغض النظر عن لغة الجهاز
    CompositionLocalProvider(
        LocalMushafColors provides c,
        LocalLayoutDirection provides LayoutDirection.Rtl,
    ) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}

/**
 * خط المصحف: إن وُجد الملف assets/fonts/uthmanic_hafs.ttf (خط مجمع الملك فهد، حفص)
 * استُخدم، وإلا استُخدم خط النظام العربي.
 */
@Composable
fun rememberQuranFont(): FontFamily {
    val context = LocalContext.current
    return remember {
        try {
            FontFamily(Typeface.createFromAsset(context.assets, "fonts/uthmanic_hafs.ttf"))
        } catch (e: Exception) {
            FontFamily.Default
        }
    }
}
